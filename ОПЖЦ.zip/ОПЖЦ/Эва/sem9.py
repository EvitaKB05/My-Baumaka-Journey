import simpy
import random
import numpy as np
import matplotlib.pyplot as plt

NUM_MACHINES = 5
NUM_REPAIRMEN = 2
SIM_TIME = 7 * 24 * 60

MEAN_PROC_TIME = 20
STD_PROC_TIME = 4

MTTF = 1000
MEAN_REPAIR_TIME = 20

SHIFT_DURATION = 8 * 60

class Machine:
    def __init__(self, env, name, repairmen):
        self.env = env
        self.name = name
        self.repairmen = repairmen
        self.parts_made = 0
        self.repairs_done = 0
        self.working_time = 0
        self.waiting_time = 0
        self.repair_time = 0
        env.process(self.run())
    
    def run(self):
        while True:
            #Работаем и делаем детали
            work_until = self.env.now + random.expovariate(1.0 / MTTF)
            while self.env.now < work_until:
                proc_time = max(0.1, random.gauss(MEAN_PROC_TIME, STD_PROC_TIME))
                if self.env.now + proc_time <= work_until:
                    yield self.env.timeout(proc_time)
                    self.parts_made += 1
                    self.working_time += proc_time
                else:
                    #Не успеваем доделать деталь до поломки
                    remaining = work_until - self.env.now
                    yield self.env.timeout(remaining)
                    self.working_time += remaining
                    break
            
            #Поломка - ждем ремонтника
            wait_start = self.env.now
            with self.repairmen.request(priority=0) as req:
                yield req
                self.waiting_time += self.env.now - wait_start
                
                #Ремонт
                repair_start = self.env.now
                repair_duration = random.expovariate(1.0 / MEAN_REPAIR_TIME)
                yield self.env.timeout(repair_duration)
                self.repair_time += self.env.now - repair_start
                self.repairs_done += 1

class Repairman:
    def __init__(self, env, name, shift_type):
        self.env = env
        self.name = name
        self.shift_type = shift_type
        self.state_log = [(0, "rest")]
        env.process(self.run())
    
    def run(self):
        if self.shift_type == "single":
            while True:
                self.state_log.append((self.env.now, "working"))
                yield self.env.timeout(SHIFT_DURATION)
                self.state_log.append((self.env.now, "rest"))
                yield self.env.timeout(16 * 60)
        else:
            #Две смены: работают по очереди 8ч через 8ч
            while True:
                self.state_log.append((self.env.now, "working"))
                yield self.env.timeout(SHIFT_DURATION)
                self.state_log.append((self.env.now, "rest"))
                yield self.env.timeout(SHIFT_DURATION)

def run_simulation(shift_type):
    random.seed(42)
    np.random.seed(42)
    
    env = simpy.Environment()
    
    #Ресурс ремонтников (доступны всегда, но в разное время)
    repairman_resource = simpy.PriorityResource(env, capacity=NUM_REPAIRMEN)
    
    #Создаем ремонтников для логирования
    repairmen = [Repairman(env, f"R{i+1}", shift_type) for i in range(NUM_REPAIRMEN)]
    
    #Создаем станки
    machines = [Machine(env, f"M{i+1}", repairman_resource) for i in range(NUM_MACHINES)]
    
    env.run(until=SIM_TIME)
    
    total_parts = sum(m.parts_made for m in machines)
    total_repairs = sum(m.repairs_done for m in machines)
    total_working = sum(m.working_time for m in machines)
    total_waiting = sum(m.waiting_time for m in machines)
    total_repair = sum(m.repair_time for m in machines)
    
    return {
        "parts": total_parts,
        "repairs": total_repairs,
        "working": total_working,
        "waiting": total_waiting,
        "repair": total_repair,
        "repairmen_logs": [(r.state_log, r.name) for r in repairmen],
    }

def plot_results(res_base, res_double):
    #Круговые диаграммы
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    total_base = res_base["working"] + res_base["waiting"] + res_base["repair"]
    total_double = res_double["working"] + res_double["waiting"] + res_double["repair"]
    
    states_base = [res_base["working"]/total_base*100, 
                   res_base["waiting"]/total_base*100,
                   res_base["repair"]/total_base*100]
    states_double = [res_double["working"]/total_double*100,
                     res_double["waiting"]/total_double*100,
                     res_double["repair"]/total_double*100]
    labels = ["Работа", "Ожидание", "Ремонт"]
    
    axes[0].pie(states_base, labels=labels, autopct="%1.1f%%")
    axes[0].set_title("Станки (1 смена)")
    
    axes[1].pie(states_double, labels=labels, autopct="%1.1f%%")
    axes[1].set_title("Станки (2 смены)")
    plt.tight_layout()
    plt.savefig("machine_states.png")
    plt.show()
    
    #Ступенчатый график ремонтников
    plt.figure(figsize=(12, 4))
    for log, name in res_base["repairmen_logs"]:
        times = [t for t, s in log]
        states = [1 if s == "working" else 0 for t, s in log]
        plt.step(times, states, where="post", label=name)
    
    plt.yticks([0, 1], ["Отдых", "Работа"])
    plt.xlabel("Время (мин)")
    plt.ylabel("Состояние")
    plt.title("Состояние ремонтников во времени (1 смена)")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("repairmen_states.png")
    plt.show()
    
    #Сравнение
    categories = ["Детали", "Ремонты", "Работа(мин)", "Ожидание(мин)", "Ремонт(мин)"]
    base_vals = [res_base["parts"], res_base["repairs"], 
                 res_base["working"], res_base["waiting"], res_base["repair"]]
    double_vals = [res_double["parts"], res_double["repairs"],
                   res_double["working"], res_double["waiting"], res_double["repair"]]
    
    x = np.arange(len(categories))
    width = 0.35
    
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.bar(x - width/2, base_vals, width, label="1 смена", color='blue')
    ax.bar(x + width/2, double_vals, width, label="2 смены", color='orange')
    ax.set_xticks(x)
    ax.set_xticklabels(categories)
    ax.legend()
    ax.set_title("Сравнение эффективности работы цеха")
    ax.grid(True, axis='y')
    plt.tight_layout()
    plt.savefig("comparison.png")
    plt.show()
    
    print("1 смена:")
    print(f"  Деталей: {res_base['parts']}")
    print(f"  Ремонтов: {res_base['repairs']}")
    print(f"  Время работы (мин): {res_base['working']:.0f}")
    print(f"  Время ожидания (мин): {res_base['waiting']:.0f}")
    print(f"  Время ремонта (мин): {res_base['repair']:.0f}")
    
    print("\n2 смены:")
    print(f"  Деталей: {res_double['parts']}")
    print(f"  Ремонтов: {res_double['repairs']}")
    print(f"  Время работы (мин): {res_double['working']:.0f}")
    print(f"  Время ожидания (мин): {res_double['waiting']:.0f}")
    print(f"  Время ремонта (мин): {res_double['repair']:.0f}")

if __name__ == "__main__":
    print("Запуск 1 смена...")
    res_base = run_simulation("single")
    print("Запуск 2 смены...")
    res_double = run_simulation("double")
    plot_results(res_base, res_double)