#include "subjects.h"
#include "ui_subjects.h"
#include "schedules.h"


Subjects::Subjects(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Subjects)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::WindowTitleHint | Qt::WindowCloseButtonHint);
    setAttribute(Qt::WA_DeleteOnClose);
    setWindowModality(Qt::ApplicationModal);

    dbconnect();
    setupModel();
    fillFacultyComboBox();
    fillSubjectsComboBox();
    setupCompleters();
    setupTableWidget();
    refreshFields();
    setupPermissions();

    connect(ui->le_search_sub, &QLineEdit::textChanged, this, &Subjects::on_le_search_sub_textChanged);
    connect(ui->twData_sub, &QTableWidget::cellClicked, this, &Subjects::onTableRowClicked);
    connect(ui->btnStud_by_Sub, &QPushButton::clicked, this, &Subjects::on_btnStud_by_Sub_clicked);
    connect(ui->btnSub_by_Fac, &QPushButton::clicked, this, &Subjects::on_btnSub_by_Fac_clicked);
    connect(ui->btnTeach_by_Sub, &QPushButton::clicked, this, &Subjects::on_btnTeach_by_Sub_clicked);

}

Subjects::~Subjects()
{
    if (dbconn.isOpen()) {
        dbconn.close();
    }
    delete ui;
}

void Subjects::dbconnect()
{
    if (!dbconn.isOpen()) {
        dbconn = QSqlDatabase::addDatabase("QPSQL", "subjects_connection");
        dbconn.setDatabaseName("ART_APP");
        dbconn.setHostName("localhost");
        dbconn.setPort(5432);
        dbconn.setUserName("postgres");
        dbconn.setPassword("mrduckword532854");

        if (!dbconn.open()) {
            QMessageBox msgBox;
            msgBox.setWindowTitle("Ошибка подключения");
            msgBox.setText("Не удалось подключиться к базе данных:\n" + dbconn.lastError().text());
            msgBox.setIcon(QMessageBox::Critical);
            msgBox.exec();
        }
    }
}

void Subjects::setupModel()
{
    model = new QSqlTableModel(this, dbconn);
    model->setTable("subjects");
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->setSort(model->fieldIndex("id_subject"), Qt::AscendingOrder);

    if (!model->select()) {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Ошибка");
        msgBox.setText("Ошибка загрузки данных:\n" + model->lastError().text());
        msgBox.setIcon(QMessageBox::Critical);
        msgBox.exec();
    }

    currentRow = 0;
}

void Subjects::setupTableWidget()
{
    ui->twData_sub->setColumnCount(4);
    ui->twData_sub->setHorizontalHeaderLabels({"ID", "Название", "Часы обучения", "Направление"});
    ui->twData_sub->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->twData_sub->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->twData_sub->setEditTriggers(QAbstractItemView::NoEditTriggers);
    refreshTableData();
    ui->twData_sub->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
}

void Subjects::refreshTableData()
{
    ui->twData_sub->setRowCount(0);

    for (int row = 0; row < model->rowCount(); ++row) {
        QSqlRecord record = model->record(row);
        ui->twData_sub->insertRow(row);

        QTableWidgetItem *idItem = new QTableWidgetItem(record.value("id_subject").toString());
        QTableWidgetItem *titleItem = new QTableWidgetItem(record.value("title").toString());
        QTableWidgetItem *hoursItem = new QTableWidgetItem(record.value("learning_hours").toString());

        QString facultyTitle = getFacultyTitleById(record.value("id_faculty").toString());
        QTableWidgetItem *facultyItem = new QTableWidgetItem(facultyTitle);

        ui->twData_sub->setItem(row, 0, idItem);
        ui->twData_sub->setItem(row, 1, titleItem);
        ui->twData_sub->setItem(row, 2, hoursItem);
        ui->twData_sub->setItem(row, 3, facultyItem);
    }
}

void Subjects::onTableRowClicked(int row)
{
    if (row >= 0 && row < ui->twData_sub->rowCount()) {
        QString id = ui->twData_sub->item(row, 0)->text();
        for (int i = 0; i < model->rowCount(); ++i) {
            if (model->record(i).value("id_subject").toString() == id) {
                currentRow = i;
                refreshFields();
                break;
            }
        }
    }
}

void Subjects::refreshFields()
{
    if(model->rowCount() == 0) {
        clearFields();
        return;
    }

    QSqlRecord record = model->record(currentRow);
    ui->le_id_sub->setText(record.value("id_subject").toString());

    // Установка названия предмета
    QString currentTitle = record.value("title").toString();
    int titleIndex = ui->cb_title_sub->findText(currentTitle, Qt::MatchFixedString);
    if(titleIndex >= 0) {
        ui->cb_title_sub->setCurrentIndex(titleIndex);
    } else {
        ui->cb_title_sub->setCurrentText(currentTitle);
    }

    ui->le_learning_hours->setText(record.value("learning_hours").toString());

    // Установка направления
    QString facultyId = record.value("id_faculty").toString();
    QString facultyTitle = getFacultyTitleById(facultyId);
    int facultyIndex = ui->cb_id_faculty->findText(facultyTitle, Qt::MatchFixedString);
    if (facultyIndex != -1) {
        ui->cb_id_faculty->setCurrentIndex(facultyIndex);
    } else {
        ui->cb_id_faculty->setCurrentText(facultyTitle);
    }

    highlightCurrentRowInTable();
}

void Subjects::clearFields()
{
    ui->le_id_sub->clear();
    ui->cb_title_sub->clearEditText();
    ui->le_learning_hours->clear();
    ui->cb_id_faculty->clearEditText();
}

void Subjects::highlightCurrentRowInTable()
{
    QString currentId = ui->le_id_sub->text();
    for (int row = 0; row < ui->twData_sub->rowCount(); ++row) {
        if (ui->twData_sub->item(row, 0)->text() == currentId) {
            ui->twData_sub->selectRow(row);
            break;
        }
    }
}

void Subjects::fillFacultyComboBox()
{
    ui->cb_id_faculty->clear();
    facultyMap.clear();
    QSqlQuery query(dbconn);

    if(!query.exec("SELECT id_faculty, title FROM faculties ORDER BY title")) {
        QMessageBox msgBox;
        msgBox.setWindowTitle("Ошибка");
        msgBox.setText("Не удалось загрузить список направлений:\n" + query.lastError().text());
        msgBox.setIcon(QMessageBox::Critical);
        msgBox.exec();
        return;
    }

    while(query.next()) {
        QString id = query.value(0).toString();
        QString title = query.value(1).toString();
        facultyMap.insert(title, id);
        ui->cb_id_faculty->addItem(title);
    }

    ui->cb_id_faculty->setEditable(true);
    ui->cb_id_faculty->setInsertPolicy(QComboBox::NoInsert);
}

void Subjects::fillSubjectsComboBox()
{
    ui->cb_title_sub->clear();
    QSqlQuery query(dbconn);
    if (!query.exec("SELECT DISTINCT title FROM subjects ORDER BY title")) {
        qCritical() << "Failed to query subject titles:" << query.lastError().text();
        return;
    }

    while (query.next()) {
        ui->cb_title_sub->addItem(query.value(0).toString());
    }

    ui->cb_title_sub->setEditable(true);
    ui->cb_title_sub->setInsertPolicy(QComboBox::NoInsert);
}

void Subjects::setupCompleters()
{
    // Автодополнение для названий предметов
    QStringList subjectsList;
    for (int i = 0; i < ui->cb_title_sub->count(); ++i) {
        subjectsList << ui->cb_title_sub->itemText(i);
    }
    QCompleter *subjectCompleter = new QCompleter(subjectsList, this);
    subjectCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    subjectCompleter->setFilterMode(Qt::MatchContains);
    ui->cb_title_sub->setCompleter(subjectCompleter);

    // Автодополнение для направлений
    QStringList facultiesList;
    for (int i = 0; i < ui->cb_id_faculty->count(); ++i) {
        facultiesList << ui->cb_id_faculty->itemText(i);
    }
    QCompleter *facultyCompleter = new QCompleter(facultiesList, this);
    facultyCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    facultyCompleter->setFilterMode(Qt::MatchContains);
    ui->cb_id_faculty->setCompleter(facultyCompleter);
}

QString Subjects::getFacultyTitleById(const QString &id)
{
    return facultyMap.key(id, "");
}

QString Subjects::getFacultyIdByTitle(const QString &title)
{
    return facultyMap.value(title, "");
}

void Subjects::on_btnPrevious_clicked()
{
    if (currentRow > 0) {
        currentRow--;
        refreshFields();
    }
}

void Subjects::on_btnNext_clicked()
{
    if (currentRow < model->rowCount() - 1) {
        currentRow++;
        refreshFields();
    }
}

void Subjects::on_btnLast_clicked()
{
    currentRow = model->rowCount() - 1;
    refreshFields();
}

void Subjects::on_btnAddNew_clicked()
{
    QMessageBox msgBox(this);
    msgBox.setWindowTitle("Добавление");
    msgBox.setText("Хотите добавить новый предмет?");
    msgBox.setIcon(QMessageBox::Question);

    QPushButton *btnYes = msgBox.addButton("Да", QMessageBox::YesRole);
    QPushButton *btnNo = msgBox.addButton("Нет", QMessageBox::NoRole);
    msgBox.setDefaultButton(btnNo);

    msgBox.exec();

    if (msgBox.clickedButton() == btnYes) {
        clearFields();
        ui->le_id_sub->setEnabled(true);
        ui->cb_title_sub->setEnabled(true);
        ui->le_learning_hours->setEnabled(true);
        ui->cb_id_faculty->setEnabled(true);
        ui->cb_title_sub->setFocus();
    }
}

void Subjects::on_btnEditRow_clicked()
{
    if(model->rowCount() == 0) return;

    QMessageBox msgBox(this);
    msgBox.setWindowTitle("Редактирование");
    msgBox.setText("Вы действительно хотите редактировать данные предмета?");
    msgBox.setIcon(QMessageBox::Question);

    QPushButton *btnYes = msgBox.addButton("Да", QMessageBox::YesRole);
    QPushButton *btnNo = msgBox.addButton("Нет", QMessageBox::NoRole);
    msgBox.setDefaultButton(btnNo);

    msgBox.exec();

    if(msgBox.clickedButton() == btnYes) {
        ui->le_id_sub->setEnabled(false);
        ui->cb_title_sub->setEnabled(true);
        ui->le_learning_hours->setEnabled(true);
        ui->cb_id_faculty->setEnabled(true);
    }
}

void Subjects::on_btnDelete_clicked()
{
    if (model->rowCount() == 0) return;

    QMessageBox msgBox(this);
    msgBox.setWindowTitle("Удаление");
    msgBox.setText("Вы действительно хотите удалить предмет?");
    msgBox.setIcon(QMessageBox::Question);

    QPushButton *btnYes = msgBox.addButton("Да", QMessageBox::YesRole);
    QPushButton *btnNo = msgBox.addButton("Нет", QMessageBox::NoRole);
    msgBox.setDefaultButton(btnNo);

    msgBox.exec();

    if (msgBox.clickedButton() == btnYes) {
        model->removeRow(currentRow);
        if (!model->submitAll()) {
            QMessageBox errorBox(this);
            errorBox.setWindowTitle("Ошибка");
            errorBox.setText("Не удалось удалить запись:\n" + model->lastError().text());
            errorBox.setIcon(QMessageBox::Critical);
            errorBox.exec();
            model->revertAll();
            return;
        }

        if (currentRow > 0) currentRow--;
        model->select();
        refreshTableData();
        refreshFields();
        fillSubjectsComboBox();

        QMessageBox infoBox(this);
        infoBox.setWindowTitle("Успех");
        infoBox.setText("Предмет удален!");
        infoBox.setIcon(QMessageBox::Information);
        infoBox.exec();
    }
}

void Subjects::on_btnSave_clicked()
{
    QString id = ui->le_id_sub->text().trimmed();
    QString title = ui->cb_title_sub->currentText().trimmed();
    QString hours = ui->le_learning_hours->text().trimmed();
    QString facultyTitle = ui->cb_id_faculty->currentText().trimmed();

    if (title.isEmpty() || hours.isEmpty() || facultyTitle.isEmpty()) {
        QMessageBox warningBox(this);
        warningBox.setWindowTitle("Ошибка");
        warningBox.setText("Все поля должны быть заполнены!");
        warningBox.setIcon(QMessageBox::Warning);
        warningBox.exec();
        return;
    }

    QString facultyId = getFacultyIdByTitle(facultyTitle);
    if (facultyId.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Указанное направление не найдено!");
        return;
    }

    QSqlRecord record;
    if (ui->le_id_sub->isEnabled()) {
        record = model->record();
        record.setValue("id_subject", id);
    } else {
        record = model->record(currentRow);
    }

    record.setValue("title", title);
    record.setValue("learning_hours", hours);
    record.setValue("id_faculty", facultyId);

    bool success = false;
    if (ui->le_id_sub->isEnabled()) {
        success = model->insertRecord(-1, record);
    } else {
        success = model->setRecord(currentRow, record);
    }

    if (!success) {
        QMessageBox errorBox(this);
        errorBox.setWindowTitle("Ошибка");
        errorBox.setText(ui->le_id_sub->isEnabled() ?
                             "Не удалось добавить запись:\n" + model->lastError().text() :
                             "Не удалось обновить запись:\n" + model->lastError().text());
        errorBox.setIcon(QMessageBox::Critical);
        errorBox.exec();
        return;
    }

    if (!model->submitAll()) {
        QMessageBox errorBox(this);
        errorBox.setWindowTitle("Ошибка");
        errorBox.setText("Ошибка сохранения:\n" + model->lastError().text());
        errorBox.setIcon(QMessageBox::Critical);
        errorBox.exec();
        model->revertAll();
        return;
    }

    model->select();
    refreshTableData();
    fillSubjectsComboBox();

    QMessageBox infoBox(this);
    infoBox.setWindowTitle("Успех");
    infoBox.setText("Данные сохранены!");
    infoBox.setIcon(QMessageBox::Information);
    infoBox.exec();

    refreshFields();
}


void Subjects::on_btn_to_schedules_clicked()
{
    Schedules *schedulesForm = new Schedules();
    schedulesForm->show();
    this->close();
}


void Subjects::on_le_search_sub_textChanged(const QString &text)
{
    QString filter = QString("title ILIKE '%%1%'").arg(text);
    model->setFilter(filter);
    if (!model->select()) {
        qDebug() << "Filter error:" << model->lastError().text();
    }
    refreshTableData();
    currentRow = 0;
    if (model->rowCount() > 0) {
        refreshFields();
    }
}

void Subjects::on_btnTeach_by_Sub_clicked()
{
    QInputDialog dialog(this);
    dialog.setWindowTitle(tr("Преподаватели по предмету"));
    dialog.setLabelText(tr("Пожалуйста, укажите предмет:"));

    // Получаем список предметов из модели или базы данных
    QStringList subjectTitles;
    QSqlQuery query("SELECT title FROM subjects ORDER BY title", dbconn);
    while (query.next()) {
        subjectTitles << query.value(0).toString();
    }

    dialog.setComboBoxItems(subjectTitles);
    dialog.setComboBoxEditable(true);
    dialog.setWindowFlags(dialog.windowFlags() | Qt::WindowTitleHint | Qt::WindowCloseButtonHint);

    dialog.setOkButtonText(tr("ОК"));
    dialog.setCancelButtonText(tr("Отмена"));

    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    QString subjectTitle = dialog.textValue();
    if (subjectTitle.isEmpty()) {
        return;
    }

    // Получаем ID предмета по его названию
    QString subjectId;
    QSqlQuery idQuery(dbconn);
    idQuery.prepare("SELECT id_subject FROM subjects WHERE title = :title");
    idQuery.bindValue(":title", subjectTitle);
    if (!idQuery.exec() || !idQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "Указанный предмет не найден!");
        return;
    }
    subjectId = idQuery.value(0).toString();

    QSqlQueryModel *teachersModel = new QSqlQueryModel(this);
    teachersModel->setQuery(QString(
                                "SELECT t.id_teacher, t.fio, t.contacts, t.post, f.title AS faculty_title "
                                "FROM teachers t "
                                "JOIN sub_teachers st ON t.id_teacher = st.id_teacher "
                                "LEFT JOIN faculties f ON t.id_faculty = f.id_faculty "
                                "WHERE st.id_subject = '%1' "
                                "ORDER BY t.fio").arg(subjectId), dbconn);

    if (teachersModel->lastError().isValid()) {
        QMessageBox::critical(this, "Ошибка", "Не удалось загрузить преподавателей:\n" + teachersModel->lastError().text());
        return;
    }

    QDialog *teachersDialog = new QDialog(this);
    teachersDialog->setWindowTitle(QString("Преподаватели предмета: %1").arg(subjectTitle));
    teachersDialog->setMinimumSize(800, 600);

    QVBoxLayout *layout = new QVBoxLayout(teachersDialog);

    QPushButton *btnPdf = new QPushButton("Отчет .pdf", teachersDialog);
    connect(btnPdf, &QPushButton::clicked, this, [this, teachersModel, subjectTitle]() {
        generateReportPdf(teachersModel, QString("Преподаватели предмета %1").arg(subjectTitle));
    });
    layout->addWidget(btnPdf);

    QTableView *tableView = new QTableView(teachersDialog);
    tableView->setModel(teachersModel);
    tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    tableView->setSelectionBehavior(QAbstractItemView::SelectRows);

    teachersModel->setHeaderData(0, Qt::Horizontal, tr("ID"));
    teachersModel->setHeaderData(1, Qt::Horizontal, tr("ФИО"));
    teachersModel->setHeaderData(2, Qt::Horizontal, tr("Контакты"));
    teachersModel->setHeaderData(3, Qt::Horizontal, tr("Должность"));
    teachersModel->setHeaderData(4, Qt::Horizontal, tr("Направление"));

    layout->addWidget(tableView);

    QPushButton *btnClose = new QPushButton("Закрыть", teachersDialog);
    connect(btnClose, &QPushButton::clicked, teachersDialog, &QDialog::close);
    layout->addWidget(btnClose);

    teachersDialog->exec();
}


void Subjects::on_btnStud_by_Sub_clicked()
{
    QInputDialog dialog(this);
    dialog.setWindowTitle(tr("Студенты по предмету"));
    dialog.setLabelText(tr("Пожалуйста, укажите предмет:"));

    // Получаем список предметов из базы данных
    QStringList subjectTitles;
    QSqlQuery query("SELECT title FROM subjects ORDER BY title", dbconn);
    while (query.next()) {
        subjectTitles << query.value(0).toString();
    }

    dialog.setComboBoxItems(subjectTitles);
    dialog.setComboBoxEditable(true);
    dialog.setWindowFlags(dialog.windowFlags() | Qt::WindowTitleHint | Qt::WindowCloseButtonHint);

    dialog.setOkButtonText(tr("ОК"));
    dialog.setCancelButtonText(tr("Отмена"));

    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    QString subjectTitle = dialog.textValue();
    if (subjectTitle.isEmpty()) {
        return;
    }

    // Получаем ID предмета по его названию
    QString subjectId;
    QSqlQuery idQuery(dbconn);
    idQuery.prepare("SELECT id_subject FROM subjects WHERE title = :title");
    idQuery.bindValue(":title", subjectTitle);
    if (!idQuery.exec() || !idQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "Указанный предмет не найден!");
        return;
    }
    subjectId = idQuery.value(0).toString();

    QSqlQueryModel *studentsModel = new QSqlQueryModel(this);
    studentsModel->setQuery(QString(
                                "SELECT s.id_student, s.fio, s.contacts, f.title as faculty "
                                "FROM students s "
                                "JOIN sub_students ss ON s.id_student = ss.id_student "
                                "JOIN faculties f ON s.id_faculty = f.id_faculty "
                                "WHERE ss.id_subject = '%1' "
                                "ORDER BY s.fio").arg(subjectId), dbconn);

    if (studentsModel->lastError().isValid()) {
        QMessageBox::critical(this, "Ошибка", "Не удалось загрузить студентов:\n" + studentsModel->lastError().text());
        return;
    }

    QDialog *studentsDialog = new QDialog(this);
    studentsDialog->setWindowTitle(QString("Студенты предмета: %1").arg(subjectTitle));
    studentsDialog->setMinimumSize(800, 600);

    QVBoxLayout *layout = new QVBoxLayout(studentsDialog);

    QPushButton *btnPdf = new QPushButton("Отчет .pdf", studentsDialog);
    connect(btnPdf, &QPushButton::clicked, this, [this, studentsModel, subjectTitle]() {
        generateReportPdf(studentsModel, QString("Студенты предмета %1").arg(subjectTitle));
    });
    layout->addWidget(btnPdf);

    QTableView *tableView = new QTableView(studentsDialog);
    tableView->setModel(studentsModel);
    tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    tableView->setSelectionBehavior(QAbstractItemView::SelectRows);

    studentsModel->setHeaderData(0, Qt::Horizontal, tr("ID"));
    studentsModel->setHeaderData(1, Qt::Horizontal, tr("ФИО"));
    studentsModel->setHeaderData(2, Qt::Horizontal, tr("Контакты"));
    studentsModel->setHeaderData(3, Qt::Horizontal, tr("Направление"));

    layout->addWidget(tableView);

    QPushButton *btnClose = new QPushButton("Закрыть", studentsDialog);
    connect(btnClose, &QPushButton::clicked, studentsDialog, &QDialog::close);
    layout->addWidget(btnClose);

    studentsDialog->exec();
}

void Subjects::on_btnSub_by_Fac_clicked()
{
    QInputDialog dialog(this);
    dialog.setWindowTitle(tr("Предметы по направлению"));
    dialog.setLabelText(tr("Пожалуйста, укажите направление:"));
    dialog.setComboBoxItems(facultyMap.keys());
    dialog.setComboBoxEditable(true);
    dialog.setWindowFlags(dialog.windowFlags() | Qt::WindowTitleHint | Qt::WindowCloseButtonHint);

    dialog.setOkButtonText(tr("ОК"));
    dialog.setCancelButtonText(tr("Отмена"));

    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    QString facultyTitle = dialog.textValue();
    if (facultyTitle.isEmpty()) {
        return;
    }

    QString facultyId = getFacultyIdByTitle(facultyTitle);
    if (facultyId.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Указанное направление не найдено!");
        return;
    }

    QSqlQueryModel *subjectsModel = new QSqlQueryModel(this);
    subjectsModel->setQuery(QString(
                                "SELECT s.id_subject, s.title, s.learning_hours "
                                "FROM subjects s "
                                "WHERE s.id_faculty = '%1' "
                                "ORDER BY s.title").arg(facultyId), dbconn);

    if (subjectsModel->lastError().isValid()) {
        QMessageBox::critical(this, "Ошибка", "Не удалось загрузить предметы:\n" + subjectsModel->lastError().text());
        return;
    }

    QDialog *subjectsDialog = new QDialog(this);
    subjectsDialog->setWindowTitle(QString("Предметы направления: %1").arg(facultyTitle));
    subjectsDialog->setMinimumSize(800, 600);

    QVBoxLayout *layout = new QVBoxLayout(subjectsDialog);

    QPushButton *btnPdf = new QPushButton("Отчет .pdf", subjectsDialog);
    connect(btnPdf, &QPushButton::clicked, this, [this, subjectsModel, facultyTitle]() {
        generateReportPdf(subjectsModel, QString("Предметы направления %1").arg(facultyTitle));
    });
    layout->addWidget(btnPdf);

    QTableView *tableView = new QTableView(subjectsDialog);
    tableView->setModel(subjectsModel);
    tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    tableView->setSelectionBehavior(QAbstractItemView::SelectRows);

    subjectsModel->setHeaderData(0, Qt::Horizontal, tr("ID"));
    subjectsModel->setHeaderData(1, Qt::Horizontal, tr("Название"));
    subjectsModel->setHeaderData(2, Qt::Horizontal, tr("Часы обучения"));

    layout->addWidget(tableView);

    QPushButton *btnClose = new QPushButton("Закрыть", subjectsDialog);
    connect(btnClose, &QPushButton::clicked, subjectsDialog, &QDialog::close);
    layout->addWidget(btnClose);

    subjectsDialog->exec();
}

void Subjects::generateReportPdf(QSqlQueryModel *model, const QString &title)
{
    QString fileName = QFileDialog::getSaveFileName(
        this,
        "Сохранить отчет как PDF",
        QString("%1.pdf").arg(title),
        "PDF Files (*.pdf)"
        );

    if (fileName.isEmpty()) {
        return;
    }

    QPdfWriter writer(fileName);
    writer.setPageSize(QPageSize(QPageSize::A4));
    writer.setPageMargins(QMarginsF(20, 20, 20, 20));
    writer.setResolution(96);

    QPainter painter(&writer);
    if (!painter.isActive()) {
        QMessageBox::critical(this, "Ошибка", "Не удалось инициализировать QPainter");
        return;
    }

    QFont titleFont("Arial", 14, QFont::Bold);
    QFont headerFont("Arial", 10, QFont::Bold);
    QFont dataFont("Arial", 9);

    const int PAGE_WIDTH = writer.width();
    const int LEFT_MARGIN = 75;
    const int TOP_MARGIN = 75;
    const int ROW_HEIGHT = 30;
    const int HEADER_HEIGHT = 35;

    int currentY = TOP_MARGIN;

    // Draw title
    painter.setFont(titleFont);
    painter.drawText(LEFT_MARGIN, currentY, title);
    currentY += 50;

    painter.setFont(dataFont);
    painter.drawText(LEFT_MARGIN, currentY,
                     "Дата формирования: " + QDateTime::currentDateTime().toString("dd.MM.yyyy HH:mm"));
    currentY += 50;

    if (model->rowCount() == 0) {
        painter.setFont(titleFont);
        painter.drawText(LEFT_MARGIN, currentY, "Нет данных для отображения");
        painter.end();
        QMessageBox::information(this, "Информация", "Нет данных для отчета.");
        return;
    }

    // Calculate column widths
    int colCount = model->columnCount();
    QVector<int> colWidths(colCount);
    int totalWidth = 0;

    for (int col = 0; col < colCount; ++col) {
        colWidths[col] = PAGE_WIDTH / colCount - 20;
        totalWidth += colWidths[col];
    }

    // Draw headers
    painter.setFont(headerFont);
    int xPos = LEFT_MARGIN;
    for (int col = 0; col < colCount; ++col) {
        painter.drawRect(xPos, currentY, colWidths[col], HEADER_HEIGHT);
        painter.drawText(
            QRect(xPos, currentY, colWidths[col], HEADER_HEIGHT),
            Qt::AlignCenter,
            model->headerData(col, Qt::Horizontal).toString()
            );
        xPos += colWidths[col];
    }
    currentY += HEADER_HEIGHT;

    // Draw data
    painter.setFont(dataFont);
    for (int row = 0; row < model->rowCount(); ++row) {
        xPos = LEFT_MARGIN;
        for (int col = 0; col < colCount; ++col) {
            QString text = model->data(model->index(row, col)).toString();
            painter.drawRect(xPos, currentY, colWidths[col], ROW_HEIGHT);
            painter.drawText(
                QRect(xPos + 5, currentY, colWidths[col] - 10, ROW_HEIGHT),
                Qt::AlignLeft | Qt::AlignVCenter,
                text
                );
            xPos += colWidths[col];
        }
        currentY += ROW_HEIGHT;
    }

    painter.end();
    QMessageBox::information(this, "Успех", QString("Отчет успешно сохранен в файл:\n%1").arg(fileName));
}

void Subjects::on_btnHome_clicked()
{
    emit returnToMainMenu();
    this->close();
}

void Subjects::setupPermissions()
{
    switch(currentUserRole) {
    case UserRole::Admin:
        // Для администратора все доступно
        break;
    case UserRole::Teacher:
        // Для преподавателя ограничиваем редактирование
        ui->btnAddNew->setVisible(false);
        ui->btnEditRow->setVisible(false);
        ui->btnDelete->setVisible(false);
        ui->btnSave->setVisible(false);
        ui->btnStud_by_Sub->setVisible(false);
        ui->btnAddNew->setEnabled(false);
        ui->btnEditRow->setEnabled(false);
        ui->btnDelete->setEnabled(false);
        ui->btnSave->setEnabled(false);
        ui->le_id_sub->setVisible(false);
        ui->lb_id_sub->setVisible(false);
        ui->le_id_sub->setEnabled(false);
        ui->cb_title_sub->setEnabled(false);
        ui->le_learning_hours->setEnabled(false);
        ui->cb_id_faculty->setEnabled(false);
        ui->btnStud_by_Sub->setEnabled(false);

        break;
    case UserRole::Student:
        // Для студента только просмотр
        ui->btnAddNew->setVisible(false);
        ui->btnEditRow->setVisible(false);
        ui->btnDelete->setVisible(false);
        ui->btnSave->setVisible(false);
        ui->btnTeach_by_Sub->setVisible(false);
        ui->btnAddNew->setEnabled(false);
        ui->btnEditRow->setEnabled(false);
        ui->btnDelete->setEnabled(false);
        ui->btnSave->setEnabled(false);
        ui->le_id_sub->setVisible(false);
        ui->lb_id_sub->setVisible(false);
        ui->le_id_sub->setEnabled(false);
        ui->cb_title_sub->setEnabled(false);
        ui->le_learning_hours->setEnabled(false);
        ui->cb_id_faculty->setEnabled(false);
        ui->btnTeach_by_Sub->setEnabled(false);
    }
}


